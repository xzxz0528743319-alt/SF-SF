-- ספר טלפונים – הקמת בסיס הנתונים של הספר הכללי ב-Supabase
-- מריצים פעם אחת: Supabase → SQL Editor → מדביקים את כל הקובץ → Run

create table if not exists public.contacts (
  id          uuid primary key default gen_random_uuid(),
  owner       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name        text not null,
  phone       text not null default '',
  phone2      text not null default '',
  city        text not null default '',
  address     text not null default '',
  father      text not null default '',
  chem        text not null default '',
  shtibel     text not null default '',
  email       text not null default '',   -- נשמר אבל לעולם לא מתפרסם
  deleted     boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists contacts_updated_idx on public.contacts (updated_at, id);

-- עדכון אוטומטי של זמן השינוי (לסנכרון)
create or replace function public.contacts_touch() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  new.owner = old.owner;  -- אי אפשר להעביר בעלות
  return new;
end $$;

drop trigger if exists contacts_touch on public.contacts;
create trigger contacts_touch before update on public.contacts
  for each row execute function public.contacts_touch();

-- הרשאות: כל משתמש רואה ומשנה ישירות רק את הרשומות שהוא הוסיף
alter table public.contacts enable row level security;

drop policy if exists "read own"   on public.contacts;
drop policy if exists "insert own" on public.contacts;
drop policy if exists "update own" on public.contacts;

create policy "read own"   on public.contacts for select using (owner = auth.uid());
create policy "insert own" on public.contacts for insert with check (owner = auth.uid());
create policy "update own" on public.contacts for update using (owner = auth.uid()) with check (owner = auth.uid());
-- אין הרשאת DELETE: מחיקה = סימון deleted, כדי שכל הטלפונים יידעו להסיר את הרשומה

-- תצוגה ציבורית לכל המשתמשים המחוברים – בלי עמודת האימייל
create or replace view public.contacts_public as
  select id, owner, name, phone, phone2, city, address, father, chem, shtibel, deleted, updated_at
  from public.contacts;

revoke all on public.contacts_public from anon, public;
grant select on public.contacts_public to authenticated;
revoke all on public.contacts from anon;
