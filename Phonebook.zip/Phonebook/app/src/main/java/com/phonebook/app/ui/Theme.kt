package com.phonebook.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs

val Brand = Color(0xFF0A6CFF)
val CallGreen = Color(0xFF1FAF5A)
val CallRed = Color(0xFFE5393B)

private val Light = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE8FF),
    onPrimaryContainer = Color(0xFF00205A),
    secondaryContainer = Color(0xFFDCE8FF),
    onSecondaryContainer = Color(0xFF00205A),
    background = Color(0xFFF4F6FA),
    onBackground = Color(0xFF14171C),
    surface = Color(0xFFF4F6FA),
    onSurface = Color(0xFF14171C),
    onSurfaceVariant = Color(0xFF5B6372),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEBEEF4),
    surfaceContainerHighest = Color(0xFFE3E7EF),
    outlineVariant = Color(0xFFE1E5EC),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF5C9DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF0A3E8F),
    onPrimaryContainer = Color(0xFFDCE8FF),
    secondaryContainer = Color(0xFF1E3A66),
    onSecondaryContainer = Color(0xFFDCE8FF),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE8EAEE),
    surface = Color(0xFF0F1115),
    onSurface = Color(0xFFE8EAEE),
    onSurfaceVariant = Color(0xFF9AA3B2),
    surfaceContainerLowest = Color(0xFF181B21),
    surfaceContainerLow = Color(0xFF181B21),
    surfaceContainer = Color(0xFF181B21),
    surfaceContainerHigh = Color(0xFF22262E),
    surfaceContainerHighest = Color(0xFF2A2F38),
    outlineVariant = Color(0xFF2A2F38),
)

@Composable
fun PhonebookTheme(content: @Composable () -> Unit) {
    val mode by Prefs.theme.collectAsState()
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp),
        ),
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, content = content)
    }
}
