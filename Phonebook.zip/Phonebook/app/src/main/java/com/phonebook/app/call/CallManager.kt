package com.phonebook.app.call

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.PhoneAccountHandle
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CallInfo(val number: String, val state: Int, val connectTime: Long)
data class AudioInfo(val muted: Boolean = false, val route: Int = CallAudioState.ROUTE_EARPIECE)

/** מחזיק את השיחה הנוכחית ומעביר פקודות (מענה, ניתוק, השתקה...) למערכת */
@Suppress("DEPRECATION")
object CallManager {
    private val _call = MutableStateFlow<CallInfo?>(null)
    val call: StateFlow<CallInfo?> = _call.asStateFlow()
    private val _audio = MutableStateFlow(AudioInfo())
    val audio: StateFlow<AudioInfo> = _audio.asStateFlow()

    var service: InCallService? = null
    var onChange: (() -> Unit)? = null

    private val calls = mutableListOf<Call>()
    private var current: Call? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = publish()
        override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
    }

    fun added(call: Call) {
        calls += call
        call.registerCallback(callback)
        current = call
        publish()
    }

    fun removed(call: Call) {
        call.unregisterCallback(callback)
        calls -= call
        if (current == call) current = calls.lastOrNull()
        publish()
    }

    private fun publish() {
        _call.value = current?.let {
            CallInfo(
                number = it.details.handle?.schemeSpecificPart ?: "",
                state = it.state,
                connectTime = it.details.connectTimeMillis,
            )
        }
        onChange?.invoke()
    }

    fun answer() {
        current?.takeIf { it.state == Call.STATE_RINGING }?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    fun hangup() {
        val c = current ?: return
        if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
    }

    fun toggleHold() {
        val c = current ?: return
        if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    fun setMuted(muted: Boolean) {
        service?.setMuted(muted)
    }

    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE)
    }

    fun dtmf(c: Char) {
        current?.let {
            it.playDtmfTone(c)
            it.stopDtmfTone()
        }
    }

    fun selectAccount(handle: PhoneAccountHandle) {
        current?.phoneAccountSelected(handle, false)
    }

    fun audioChanged(state: CallAudioState) {
        _audio.value = AudioInfo(state.isMuted, state.route)
    }
}
