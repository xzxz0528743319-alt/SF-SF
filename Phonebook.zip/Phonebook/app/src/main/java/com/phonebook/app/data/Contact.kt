package com.phonebook.app.data

/**
 * איש קשר. אותו מבנה משמש לספר האישי ולספר הכללי.
 * owner = מזהה המשתמש שהוסיף את הרשומה לספר הכללי (ריק בספר האישי).
 */
data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val phone2: String = "",
    val city: String = "",
    val address: String = "",
    val father: String = "",
    val chem: String = "",
    val shtibel: String = "",
    val email: String = "",
    val owner: String = "",
) {
    val subtitle: String
        get() = listOf(city, shtibel).filter { it.isNotBlank() }.joinToString(" · ")
}

object Phone {
    fun digits(s: String): String = s.filter { it.isDigit() }

    /** 9 הספרות האחרונות – מזהה מספר בלי קשר לקידומת 0 / 972+ */
    fun tail(s: String): String {
        val d = digits(s)
        return if (d.length >= 7) d.takeLast(9) else ""
    }

    fun isAbroad(s: String): Boolean {
        val t = s.trim().replace(" ", "").replace("-", "")
        return (t.startsWith("+") && !t.startsWith("+972")) ||
            (t.startsWith("00") && !t.startsWith("00972"))
    }

    /** פורמט בינלאומי ללא + (לוואטסאפ) */
    fun international(s: String): String {
        val t = s.trim()
        var d = digits(t)
        if (t.startsWith("+")) return d
        if (d.startsWith("00")) return d.drop(2)
        if (d.startsWith("0")) d = "972" + d.drop(1)
        return d
    }
}
