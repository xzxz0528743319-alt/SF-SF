@file:OptIn(ExperimentalMaterial3Api::class)

package com.phonebook.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.ImportExport
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun SettingsScreen(onClose: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        OverlayTopBar("הגדרות", onClose)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section("חשבון וספר כללי") { AccountSection() }
            Section("ייבוא וגיבוי") { ImportExportSection() }
            Section("סיסמת מחיקה") { DeletePasswordSection() }
            Section("עוזרת AI") { AiSection() }
            Section("מראה") { ThemeSection() }
            Section("ברירת מחדל והרשאות") { DefaultsSection() }
            Text(
                "ללא פרסומות וללא מעקב. אנשי קשר בספר האישי נשמרים רק בטלפון.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(4.dp)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    AppCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun Input(label: String, value: String, password: Boolean = false, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else type),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AccountSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val session by Prefs.session.collectAsState()
    var url by remember { mutableStateOf(Prefs.serverUrl) }
    var key by remember { mutableStateOf(Prefs.serverKey) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(!Server.configured()) }
    val dbv by LocalDb.changes.collectAsState()
    val count by produceState(0, dbv) { value = withContext(Dispatchers.IO) { LocalDb.count(LocalDb.SHARED) } }

    fun go(block: suspend () -> Unit) = scope.launch {
        busy = true
        runCatching { block() }.onFailure { toast(ctx, it.message ?: "שגיאה") }
        busy = false
    }

    if (showServer) {
        Text("פרטי השרת של הספר הכללי (מקבלים פעם אחת ממי שהקים את השרת):", style = MaterialTheme.typography.bodySmall)
        Input("כתובת שרת", url, type = KeyboardType.Uri) { url = it }
        Input("מפתח ציבורי", key) { key = it }
        Button(onClick = {
            Prefs.serverUrl = url; Prefs.serverKey = key
            showServer = !Server.configured()
            toast(ctx, if (Server.configured()) "נשמר" else "חסרים פרטים")
        }) { Text("שמור פרטי שרת") }
    } else {
        TextButton(onClick = { showServer = true }) { Text("שינוי פרטי שרת") }
    }

    if (session == null) {
        Input("אימייל", email, type = KeyboardType.Email) { email = it }
        Input("סיסמה (לפחות 6 תווים)", password, password = true) { password = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = {
                go { Server.signIn(email, password); toast(ctx, "התחברת"); SharedBook.sync() }
            }) { Text("התחברות") }
            OutlinedButton(enabled = !busy, onClick = {
                go {
                    if (Server.signUp(email, password)) {
                        toast(ctx, "נרשמת והתחברת"); SharedBook.sync()
                    } else toast(ctx, "נשלח אליך מייל אישור. אשר אותו ואז התחבר.")
                }
            }) { Text("הרשמה") }
        }
        Text("האימייל משמש רק להתחברות ולא מתפרסם.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Text("מחובר: ${ltr(session ?: "")}")
        Text("רשומות בספר הכללי: $count")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { go { val n = SharedBook.sync(); toast(ctx, "סונכרן ($n עדכונים)") } }) { Text("סנכרן עכשיו") }
            OutlinedButton(enabled = !busy, onClick = {
                Server.logout()
                LocalDb.clear(LocalDb.SHARED)
            }) { Text("התנתק") }
        }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
}

@Composable
private fun ImportExportSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            runCatching { ImportExport.import(ctx, uri) }
                .onSuccess { r ->
                    val parts = mutableListOf("נוספו ${r.personal} לספר האישי")
                    if (r.shared > 0) parts += "${r.shared} לספר הכללי"
                    if (r.duplicates > 0) parts += "${r.duplicates} כפולים דולגו"
                    if (r.skippedShared > 0) parts += "${r.skippedShared} רשומות 'כללי' דולגו – צריך להתחבר קודם"
                    toast(ctx, parts.joinToString(", "))
                }
                .onFailure { toast(ctx, "הייבוא נכשל: ${it.message}") }
            busy = false
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            runCatching { ImportExport.exportCsv(ctx, uri) }
                .onSuccess { toast(ctx, "נשמרו $it אנשי קשר") }
                .onFailure { toast(ctx, "הגיבוי נכשל: ${it.message}") }
            busy = false
        }
    }

    Text(
        "ייבוא קובץ VCF או CSV. עמודות ה-CSV: שם, טלפון, טלפון 2, עיר, כתובת, שם האב, חם, שטיבל, אימייל, ספר. " +
            "בעמודה 'ספר' כותבים 'כללי' או 'אישי' (ברירת מחדל: אישי).",
        style = MaterialTheme.typography.bodySmall
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = !busy, onClick = { importer.launch(arrayOf("*/*")) }) { Text("ייבוא קובץ") }
        OutlinedButton(enabled = !busy, onClick = { exporter.launch("phonebook-backup-${LocalDate.now()}.csv") }) { Text("גיבוי ל-CSV") }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
}

@Composable
private fun DeletePasswordSection() {
    val ctx = LocalContext.current
    var has by remember { mutableStateOf(Prefs.hasDeletePassword) }
    var old by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    Text(
        if (has) "מוגדרת סיסמה. כל מחיקה של איש קשר תדרוש אותה." else "אופציונלי: סיסמה שתידרש לפני כל מחיקה.",
        style = MaterialTheme.typography.bodySmall
    )
    if (has) Input("סיסמה נוכחית", old, password = true) { old = it }
    Input(if (has) "סיסמה חדשה (ריק = ביטול הסיסמה)" else "סיסמה חדשה", pw, password = true) { pw = it }
    Button(onClick = {
        if (!Prefs.checkDeletePassword(old)) {
            toast(ctx, "הסיסמה הנוכחית שגויה"); return@Button
        }
        Prefs.setDeletePassword(pw)
        has = Prefs.hasDeletePassword
        old = ""; pw = ""
        toast(ctx, if (has) "הסיסמה נשמרה" else "הסיסמה בוטלה")
    }) { Text("שמור") }
}

@Composable
private fun AiSection() {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.aiKey) }
    var model by remember { mutableStateOf(Prefs.aiModel) }
    Text("העוזרת עובדת עם מפתח API של Anthropic (Claude). המפתח נשמר רק בטלפון.", style = MaterialTheme.typography.bodySmall)
    Input("מפתח API", key, password = true) { key = it }
    Input("מודל", model) { model = it }
    Button(onClick = { Prefs.aiKey = key; Prefs.aiModel = model.ifBlank { "claude-haiku-5-5" }; toast(ctx, "נשמר") }) { Text("שמור") }
}

@Composable
private fun ThemeSection() {
    val mode by Prefs.theme.collectAsState()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("לפי הטלפון", "בהיר", "כהה").forEachIndexed { i, label ->
            FilterChip(selected = mode == i, onClick = { Prefs.setTheme(i) }, label = { Text(label) })
        }
    }
}
