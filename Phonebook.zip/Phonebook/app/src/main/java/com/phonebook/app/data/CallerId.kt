package com.phonebook.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class CallerInfo(val name: String, val detail: String, val source: String)

/** זיהוי מספר: ספר אישי ← ספר כללי ← אנשי הקשר של הטלפון */
object CallerId {
    fun lookup(ctx: Context, number: String): CallerInfo? {
        if (number.isBlank()) return null
        try {
            LocalDb.findByPhone(LocalDb.PERSONAL, number)?.let {
                return CallerInfo(it.name, it.subtitle, "ספר אישי")
            }
            LocalDb.findByPhone(LocalDb.SHARED, number)?.let {
                return CallerInfo(it.name, it.subtitle, "ספר כללי")
            }
        } catch (_: Exception) {
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
                ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) return CallerInfo(c.getString(0) ?: number, "", "אנשי קשר בטלפון") }
            } catch (_: Exception) {
            }
        }
        return null
    }
}
